import pygame
import sys
from character import Character
import os

# Initialize Pygame
pygame.init()
pygame.mixer.init()
jumpscare_sound = pygame.mixer.Sound("jumpscare.mp3")
win_sound = pygame.mixer.Sound("win.mp3")
ding_sound = pygame.mixer.Sound("ding.mp3")
# Constants
WIDTH, HEIGHT = 1500, 720
FPS = 165
CAMERA_WIDTH, CAMERA_HEIGHT = 300, 300
ITEMS_REQUIRED = 4
initial_x = 30
initial_y = 30
# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Player properties
player_size = 35
player_x, player_y = 30, 30
player_speed = 4
on_ground = False
items_collected = 0

player = Character(initial_x, initial_y, player_speed)

# Function to load maze from file
def load_maze_from_file(file_path):
    with open(file_path, 'r') as file:
        return [list(line.strip()) for line in file]
    
# Load the maze level
level1 = load_maze_from_file('level1.txt')

# Calculate level dimensions
level_width = max(len(line) for line in level1) * 30  # Adjust if cell size is different
level_height = len(level1) * 30  # Adjust if cell size is different

# List of maze configurations
levels = [
    level1
    # Add more levels as needed
]

# Load images
player_img = pygame.image.load("character.gif")
wall_img = pygame.image.load("wall.png")
goal_img = pygame.image.load("goal.png")
item_img = pygame.image.load("item.png")
background_img = pygame.image.load("background.jpg")
jumpscare_img = pygame.image.load("jumpscare.jpg")

# Resize images to match the cell size
player_img = pygame.transform.scale(player_img, (player_size, player_size))
wall_img = pygame.transform.scale(wall_img, (30, 30))
goal_img = pygame.transform.scale(goal_img, (30, 30))
item_img = pygame.transform.scale(item_img,(30, 30))
background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT))
jumpscare_img = pygame.transform.scale(jumpscare_img, (WIDTH, HEIGHT))
# Initialize the game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Maze Game")

# Clock to control the frame rate
clock = pygame.time.Clock()

def draw_maze(level, offset_x, offset_y):
    for i, row in enumerate(level):
        for j, cell in enumerate(row):
            x, y = j * 30, i * 30
            if 0 <= x - offset_x < WIDTH and 0 <= y - offset_y < HEIGHT:
                if cell == "#":
                    screen.blit(wall_img, (x - offset_x, y - offset_y))
                elif cell == "E":
                    screen.blit(goal_img, (x - offset_x, y - offset_y))
                elif cell == "V":
                    screen.blit(item_img, (x - offset_x, y - offset_y))


def check_collision_with_items(player_rect, level):
    global items_collected
    player_cell_x, player_cell_y = player_rect.x // 30, player_rect.y // 30
    if level[player_cell_y][player_cell_x] == "V":
        level[player_cell_y][player_cell_x] = " "  # Remove the item from the maze
        items_collected += 1
        ding_sound.play()
        print(f"Items remaining: {ITEMS_REQUIRED - items_collected}")


def check_collision_with_traps(player_rect, level):
    player_cell_x, player_cell_y = player_rect.x // 30, player_rect.y // 30
    if level[player_cell_y][player_cell_x] == "F":
        trigger_jumpscare()  # Trigger the jumpscare and shut down

# Define a function for the jumpscare
def trigger_jumpscare():
    jumpscare_sound.play()
    screen.blit(jumpscare_img, (0, 0))
    pygame.display.flip()
    pygame.time.wait(2000)
    sys.exit()
    # Uncomment the next line to shut down the computer (not recommended)
    #os.system("shutdown /s /t 1")


# Define a function to reset the game
def reset_game():
    global game_active, show_start_screen, player_x, player_y, monster_spawn_time, entity_x, entity_y
    game_active = False
    show_start_screen = True
    player_x, player_y = 30, 30  # Reset player position
    entity_x, entity_y = 30, 30  # Reset entity position
    monster_spawn_time = None  # Reset monster spawn timer

def draw_player():
    # Draw the player at the center of the screen
    # Calculate the center position of the screen
    center_x = WIDTH // 2 - player_size // 2
    center_y = HEIGHT // 2 - player_size // 2

    # Draw the animated character at the screen's center
    player.draw(screen, center_x, center_y)

def update_camera(player_x, player_y, level_width, level_height):
    global camera_x, camera_y
        # Center of the screen threshold
    screen_center_x = WIDTH // 2
    screen_center_y = HEIGHT // 2
    new_camera_x = player_x - WIDTH // 2
    new_camera_y = player_y - HEIGHT // 2
    # Check if the player is far enough to move the camera
    camera_x = player_x - WIDTH // 2
    camera_y = player_y - HEIGHT // 2
    #print(f"Player Position: ({player_x}, {player_y})")
    #print(f"Camera Threshold X: {screen_center_x}, Level Width: {level_width}, {level_height}")
    #print(f"New Camera Position: ({new_camera_x}, {new_camera_y}), Adjusted Camera Position: ({camera_x}, {camera_y})")

def draw_start_screen():
    screen.blit(background_img, (0, 0))
    font = pygame.font.Font(None, 36)
    text = font.render("Welcome to Whispering Coils: Echoes of the Eldritch Maze! Press Enter to Start ", True, WHITE)
    screen.blit(text, (WIDTH // 4, HEIGHT // 2))

def draw_end_screen():
    win_sound.play()
    screen.blit(background_img, (0, 0))
    font = pygame.font.Font(None, 36)
    text = font.render("You Escaped !", True, WHITE)
    screen.blit(text, (WIDTH // 4, HEIGHT // 2))



monster_spawn_time = None
show_start_screen = True
monster_spawn_time = None
monster_has_spawned = False
player_path = []

# Game loop
running = True
current_level = 0
game_active = False
camera_x, camera_y = 0, 0

while running:
    player.update_frame()
    if show_start_screen:
        # Handle events in the start screen
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN: 
                if event.key == pygame.K_RETURN:
                    show_start_screen = False
                    game_active = True
                    camera_x, camera_y = 0, 0

        draw_start_screen()
        pygame.display.flip()



    if game_active:
        current_time = pygame.time.get_ticks()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    

        keys = pygame.key.get_pressed()
        previous_position = (player_x, player_y)
        if keys[pygame.K_a]:
            next_x = player_x - player_speed
            player.update_direction('left')
            if levels[current_level][player_y // 30][next_x // 30] != "#":
                player_x = next_x

        # Moving Right
        if keys[pygame.K_d]:
            next_x = player_x + player_speed
            player.update_direction('right')
            if levels[current_level][player_y // 30][(next_x + player_size - 1) // 30] != "#":
                player_x = next_x

        # Moving Up
        if keys[pygame.K_w]:
            next_y = player_y - player_speed
            player.update_direction('left')
            if levels[current_level][next_y // 30][player_x // 30] != "#" and \
               levels[current_level][next_y // 30][(player_x + player_size - 1) // 30] != "#":
                player_y = next_y

        # Moving Down
        if keys[pygame.K_s]:
            next_y = player_y + player_speed
            player.update_direction('right')
            if levels[current_level][(next_y + player_size - 1) // 30][player_x // 30] != "#" and \
               levels[current_level][(next_y + player_size - 1) // 30][(player_x + player_size - 1) // 30] != "#":
                player_y = next_y

        # Clear the screen and draw the background
            screen.blit(background_img, (0, 0))

            # Draw maze and entities for the current level
            draw_maze(levels[current_level], camera_x, camera_y)
            draw_player()

        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        check_collision_with_items(player_rect, levels[current_level])
        check_collision_with_traps(player_rect, levels[current_level])

        # Update camera position
        update_camera(player_x, player_y, level_width, level_height)


        # Clear the screen
        screen.blit(background_img, (0, 0))

    
        # Draw maze and entities for the current level
        draw_maze(levels[current_level], camera_x, camera_y)
        draw_player()


        # Check if the player has reached the endpoint
        if items_collected == ITEMS_REQUIRED and levels[current_level][player_y // 30][player_x // 30] == "E":
            draw_end_screen()
            pygame.display.flip()
            pygame.time.wait(1500)
            reset_game()
            game_active = False  # Set game_active to False after showing the end screen
            show_start_screen = True

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(FPS)

pygame.quit()
sys.exit()