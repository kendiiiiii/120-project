import pygame

class Character:
    def __init__(self, x, y, player_speed):
        self.x = x
        self.y = y
        self.speed = player_speed
        self.frame = 0
        self.direction = 'down'  # Initial direction
        self.load_sprites()

    def load_sprites(self):
        # Load sprite images for each direction
        self.walk_right_images = [pygame.image.load("1.png"), 
                                  pygame.image.load("2.png"),
                                  pygame.image.load("3.png")]
        self.walk_left_images = [pygame.image.load("4.png"), 
                                 pygame.image.load("5.png"),
                                 pygame.image.load("6.png")]
        self.walk_up_images = [pygame.image.load("4.png"), 
                               pygame.image.load("5.png"),
                               pygame.image.load("6.png")]
        self.walk_down_images = [pygame.image.load("1.png"), 
                                 pygame.image.load("2.png"),
                                 pygame.image.load("3.png")]
        # Set the current sprite list (initially facing down)
        self.current_sprites = self.walk_down_images

    def update_frame(self):
        # Increment the frame index
        self.frame = (self.frame + 1) % len(self.current_sprites)

    def update_direction(self, direction):
        # Update the direction and the current sprite list
        self.direction = direction
        if direction == 'right':
            self.current_sprites = self.walk_right_images
        elif direction == 'left':
            self.current_sprites = self.walk_left_images
        elif direction == 'up':
            self.current_sprites = self.walk_up_images
        elif direction == 'down':
            self.current_sprites = self.walk_down_images

    def move(self, dx, dy):
        # Update the character's position
        self.x += dx
        self.y += dy

    def draw(self, screen, x, y):
        # Draw the character on the screen using the current frame at (x, y)
        screen.blit(self.current_sprites[self.frame], (x, y))
