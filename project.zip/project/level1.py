from PIL import Image
import numpy as np
import os

# Load the image
image_path = 'level.jpeg'  # Replace with your image path
maze_image = Image.open(image_path).convert('L')  # Convert to grayscale

# Resize the image to reduce complexity (optional, adjust the size accordingly)
maze_image = maze_image.resize((100, 100))

# Threshold the image
threshold = 128  # This is a guess; you may need to adjust it
binary_maze = np.array(maze_image) > threshold  # True for white (path), False for black (wall)

# Convert the binary array to a text-based level format
level_data = []
for row in binary_maze:
    level_row = []
    for cell in row:
        level_row.append(' ' if cell else '#')  # Space for path, # for wall
    level_data.append(''.join(level_row))

# Set the starting point's position (for example, 2 rows down from the top and from the right)
start_y_position = 2  # Change this to the desired Y position
start_x_position = 2  # Change this to the desired X position
end_y_position = 2    # Change this to the desired Y position
end_x_position = 97   # Change this to the desired X position

# Clear any previous 'S' and 'E' in the level_data if necessary
for i in range(len(level_data)):
    level_data[i] = level_data[i].replace('S', ' ').replace('E', ' ')

# Set the starting point (at the adjusted X and Y position)
level_data[start_y_position] = (level_data[start_y_position][:start_x_position] + 'S' + level_data[start_y_position][start_x_position + 1:])

# Set the ending point (at the adjusted X and Y position)
level_data[end_y_position] = (level_data[end_y_position][:end_x_position] + 'E' + level_data[end_y_position][end_x_position + 1:])


# Print out the level data or save it to a file
for row in level_data:
    print(row)

# Set the file name
output_file_name = 'level.txt'

# Save the level data to the file
try:
    with open(output_file_name, 'w') as file:
        for row in level_data:
            file.write(row + '\n')
except IOError as e:
    print(f"An error occurred: {e}")


